
public class Settings {

	public static String username = "root";
	public static String pass = "25Dominic13";
}
